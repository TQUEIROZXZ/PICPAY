package tech.buildrun.picpay.client.dto;

public record AuthorizationResponse(boolean authorized) {
}
